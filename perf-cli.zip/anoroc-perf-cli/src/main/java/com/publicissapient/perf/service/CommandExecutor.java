package com.publicissapient.perf.service;

import com.publicissapient.perf.printer.ConsolePrinter;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.HashMap;
import java.util.Map;

@Component
@Slf4j
public class CommandExecutor {
    private  Map<String, String> config;

    @PostConstruct
    public void setUp() {
        config= new HashMap<>();
    }

    public Map<String, String> getConfig() {
        return config;
    }

    public void addConfig(String key, String value) {
        config.put(key, value);
    }

    public void execute(String command) throws IOException, InterruptedException {
        Process proc = Runtime.getRuntime().exec(command);
        // Read the output
        BufferedReader reader = new BufferedReader(new InputStreamReader(proc.getInputStream()));
        String line = "";
        while((line = reader.readLine()) != null) {
            ConsolePrinter.printlnCyan(line);
        }
        proc.waitFor();
    }
}
