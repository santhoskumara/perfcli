package com.publicissapient.perf.command;

import com.publicissapient.perf.service.CommandExecutor;
import com.publicissapient.perf.service.ReportGenerator;
import com.publicissapient.perf.printer.ConsolePrinter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.shell.standard.ShellComponent;
import org.springframework.shell.standard.ShellMethod;
import org.springframework.shell.standard.ShellOption;

import java.io.IOException;
import java.net.URISyntaxException;
import java.net.URL;
import java.nio.file.Paths;

@ShellComponent
public class RunKarateCommand{

    @Autowired
    private CommandExecutor commandExecutor;

    @Autowired
    private ReportGenerator reportGenerator;

    @Autowired
    private Command command;

    @ShellMethod("Run performance test for karate feature using gatling engine")
    public void run_karate(@ShellOption("simulationName") String simulationName, @ShellOption("args") String args) throws IOException, InterruptedException, URISyntaxException {
        ConsolePrinter.printlnCyan("Gatling Home Set : "+command.getGatlingHome());
        URL url = (getClass().getClassLoader().getResource("karate-run.sh"));
        String path = Paths.get(url.toURI()).toString();
        commandExecutor.execute(path+" "+command.getGatlingHome()+" "+simulationName+" "+args);
        reportGenerator.generateReport(command.getGatlingHome(), command.getReportPath());
    }

}
