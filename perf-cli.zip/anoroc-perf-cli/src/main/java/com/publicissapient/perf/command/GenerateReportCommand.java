package com.publicissapient.perf.command;

import com.publicissapient.perf.service.ReportGenerator;
import com.publicissapient.perf.printer.ConsolePrinter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.shell.standard.ShellComponent;
import org.springframework.shell.standard.ShellMethod;
import org.springframework.shell.standard.ShellOption;

import java.io.IOException;
import java.net.URISyntaxException;
import java.net.URL;
import java.nio.file.Paths;

@ShellComponent
public class GenerateReportCommand {

    @Value("${anoroc.perf.simulation.dir:user-files/simulations/}")
    private String simulationDir;

    @Autowired
    private Command command;

    @Autowired
    ReportGenerator reportGenerator;

    @ShellMethod("Generate Gatling Report for the simulation")
    public void generate_report() throws IOException, InterruptedException, URISyntaxException {
        ConsolePrinter.printlnCyan("Gatling Home Set : "+command.getGatlingHome());
        URL url = (getClass().getClassLoader().getResource(command.getReportScripts()));
        reportGenerator.generateReport(command.getGatlingHome(), Paths.get(url.toURI()));
    }

}
