package com.publicissapient.perf;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.BufferedReader;
import java.io.InputStreamReader;

@SpringBootApplication
public class AnorocPerfCliApplication {

	public static void main(String[] args) throws IOException, InterruptedException {
			SpringApplication.run(AnorocPerfCliApplication.class, args);
	}

}
