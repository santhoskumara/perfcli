package com.publicissapient.perf.command;

import com.intuit.karate.FileUtils;
import com.publicissapient.perf.service.CommandExecutor;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.io.File;
import java.io.IOException;
import java.net.URISyntaxException;
import java.net.URL;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

import static com.publicissapient.perf.command.SetUpGatlingCommand.GATLING_HOME;


@Component
public class Command {

    private static final String MAC_LINUX_GATLING_SCRIPT = "gatling-run.sh";
    private static final String WINDOWS_GATLING_SCRIPT = "gatling-run.bat";
    private static final String SIMULATION_FILE_EXT = ".scala";
    private static final String MAC_LINUX_GATLING_REPORT_SCRIPT = "gatling-reports.sh";
    private static final String WINDOWS_GATLING_REPORT_SCRIPT = "gatling-reports.bat";

    @Value("${anoroc.perf.simulation.dir:user-files/simulations/}")
    private String simulationDir;

    @Autowired
    private CommandExecutor commandExecutor;

    protected String getGatlingHome() {
        return commandExecutor.getConfig().get(GATLING_HOME);
    }

    protected void copySimulationFiles(String srcSimulationFolder, String simulationName) throws IOException {
        if(StringUtils.isEmpty(srcSimulationFolder)){
            return;
        }
        Path srcSimulationFilePath = Paths.get(srcSimulationFolder+ File.separator+simulationName+SIMULATION_FILE_EXT);
        String targetSimulationFilePathStr = getGatlingHome()+File.separator+simulationDir+File.separator+simulationName+SIMULATION_FILE_EXT;
        Path targetSimulationFilePath = Paths.get(targetSimulationFilePathStr);
        File targetSimulationFile = new File(targetSimulationFilePath.toUri());
        if(targetSimulationFile.exists()) {
            targetSimulationFile.delete();
        }
        Files.copy(srcSimulationFilePath, targetSimulationFilePath);
    }

    protected String getScripts() {
        String scriptName = MAC_LINUX_GATLING_SCRIPT;
        if(FileUtils.isOsWindows()) {
            scriptName = WINDOWS_GATLING_SCRIPT;
        }
        return scriptName;
    }

    protected String getReportScripts() {
        String scriptName = MAC_LINUX_GATLING_REPORT_SCRIPT;
        if(FileUtils.isOsWindows()) {
            scriptName = WINDOWS_GATLING_REPORT_SCRIPT;
        }
        return scriptName;
    }

    public Path getReportPath() throws URISyntaxException {
        URL url = (getClass().getClassLoader().getResource(getReportScripts()));
        return Paths.get(url.toURI());
    }
}
