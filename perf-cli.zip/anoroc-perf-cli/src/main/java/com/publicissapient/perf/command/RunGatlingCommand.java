package com.publicissapient.perf.command;

import com.publicissapient.perf.service.CommandExecutor;
import com.publicissapient.perf.service.ReportGenerator;
import com.publicissapient.perf.printer.ConsolePrinter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.shell.standard.ShellComponent;
import org.springframework.shell.standard.ShellMethod;
import org.springframework.shell.standard.ShellOption;

import java.io.IOException;
import java.net.URISyntaxException;
import java.net.URL;
import java.nio.file.Paths;

@ShellComponent
public class RunGatlingCommand {

    @Value("${anoroc.perf.simulation.dir:user-files/simulations/}")
    private String simulationDir;

    @Autowired
    private CommandExecutor commandExecutor;

    @Autowired
    private ReportGenerator reportGenerator;

    @Autowired
    private Command command;

    @ShellMethod("Run performance test for gatling scripts")
    public void run_gatling(@ShellOption("simulationName") String simulationName, @ShellOption(value = "simulationFolder", defaultValue = "") String simulationFolder) throws IOException, InterruptedException, URISyntaxException {
        ConsolePrinter.printlnCyan("Gatling Home Set : "+command.getGatlingHome());
        command.copySimulationFiles(simulationFolder, simulationName);
        URL url = getClass().getClassLoader().getResource(command.getScripts());
        String path = Paths.get(url.toURI()).toString();
        commandExecutor.execute(path+" "+command.getGatlingHome()+" "+simulationName);
        reportGenerator.generateReport(command.getGatlingHome(), command.getReportPath());
    }
}
