package com.publicissapient.perf.command;


import com.publicissapient.perf.service.CommandExecutor;
import com.publicissapient.perf.printer.ConsolePrinter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.shell.standard.ShellComponent;
import org.springframework.shell.standard.ShellMethod;
import org.springframework.shell.standard.ShellOption;

import java.io.File;
import java.io.IOException;
import java.net.URISyntaxException;
import java.net.URL;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

@ShellComponent
public class SetUpGatlingCommand {

    @Autowired
    private CommandExecutor gatlingExecutor;

    @Autowired
    private CommandExecutor commandExecutor;

    @Autowired
    private Command command;

    public static final String GATLING_HOME="GATLING_HOME";
    public static final String GATLING_RUNNER_BUNDLE="gatling-charts-highcharts-bundle-3.3.1";
    public static final String GATLING_RUNNER_BUNDLE_EXTENSION=".zip";

    @ShellMethod("setup the gatling home config path")
    public void setup(String gatlingHome) {
        gatlingExecutor.addConfig(GATLING_HOME, gatlingHome);
        ConsolePrinter.printlnCyan("Gatling Home Set : "+gatlingHome);
    }

    @ShellMethod("Download the bundleScripts")
    public void download(@ShellOption("gatlingHomeFolder") String gatlingHomeFolder) throws IOException, InterruptedException, URISyntaxException {
        URL url = getClass().getClassLoader().getResource(GATLING_RUNNER_BUNDLE+GATLING_RUNNER_BUNDLE_EXTENSION);
        String targetDir = gatlingHomeFolder+File.separator+GATLING_RUNNER_BUNDLE;
        String targetFile = targetDir+GATLING_RUNNER_BUNDLE_EXTENSION;
        Path srcBundlePath = Paths.get(url.toURI());
        Path targetBundlePath = Paths.get(targetFile);
        Files.copy(srcBundlePath, targetBundlePath);
        setup(targetDir);
    }
}
