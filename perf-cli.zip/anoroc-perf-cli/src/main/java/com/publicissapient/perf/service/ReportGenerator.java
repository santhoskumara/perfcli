package com.publicissapient.perf.service;

import com.publicissapient.perf.printer.ConsolePrinter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.net.URISyntaxException;
import java.nio.file.Path;

@Component
public class ReportGenerator {

    @Autowired
    private CommandExecutor commandExecutor;

    public void generateReport(String gatlingHome, Path reportPath) throws IOException, InterruptedException, URISyntaxException {
        ConsolePrinter.printlnCyan("Report Path "+reportPath);
        String path = reportPath.toString();
        commandExecutor.execute(path+" "+gatlingHome);
    }
}
