# Assuming same user name for all hosts
USER_NAME='local'

# Assuming all Gatling installation in same path (with write permissions)
GATLING_HOME=$1

# Change to your simulation class name
SIMULATION_NAME=$2
GATLING_SIMULATIONS_DIR=$GATLING_HOME/user-files/simulations
GATLING_RUNNER=$GATLING_HOME/bin/gatling.sh

# No need to change this
GATLING_REPORT_DIR=$GATLING_HOME/results/
GATHER_REPORTS_DIR=$GATLING_HOME/gatling/reports/

echo "Starting Gatling cluster run for simulation: $SIMULATION_NAME"

echo "Cleaning previous runs from localhost"
echo "Report dir $GATLING_REPORT_DIR"
echo "Gather Report dir $GATHER_REPORTS_DIR"
rm -rf $GATHER_REPORTS_DIR
mkdir $GATHER_REPORTS_DIR
rm -rf $GATLING_REPORT_DIR

echo "Running simulation on localhost"
$GATLING_RUNNER -nr -s $SIMULATION_NAME


# using ubuntu
# google-chrome ${GATLING_REPORT_DIR}reports/index.html
